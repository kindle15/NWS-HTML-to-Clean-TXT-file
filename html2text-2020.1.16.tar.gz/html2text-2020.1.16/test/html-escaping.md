Escaped HTML like <div> or & should NOT remain escaped on output

    
    
    ...even when that escaped HTML is in a <pre> tag

`...or a <code> tag`

