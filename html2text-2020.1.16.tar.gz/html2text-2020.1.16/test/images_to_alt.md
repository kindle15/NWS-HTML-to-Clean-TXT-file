[ ALT TEXT ](http://example.com)  
[ALT TEXT](http://example.com)  
<http://example.com>

