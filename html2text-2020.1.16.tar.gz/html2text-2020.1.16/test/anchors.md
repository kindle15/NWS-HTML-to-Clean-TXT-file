# Processing hyperlinks

Additional hyperlink tests!

[**Bold Link**](http://some.link)
[`filename.py`](http://some.link/filename.py) [The source code is called
`magic.py`](http://some.link/magicsources.py)

