# Processing images with links

This test checks images with associated links.

[![\(banana\)](http://placehold.it/350x150#\(banana\))](http://some.link)
[![\[banana\]](http://placehold.it/350x150#\[banana\])](http://some.link)
[![{banana}](http://placehold.it/350x150#{banana})](http://some.link)
[![\(\[{}\]\)](http://placehold.it/350x150#\(\[{}\]\))](http://some.link)
[![](http://placehold.it/350x150#\(\[{}\]\))](http://some.link)

