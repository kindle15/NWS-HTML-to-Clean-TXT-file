**font-weight: bold**   
**FONT-WEIGHT: BOLD**   
**font-weight: 700**   
**FONT-WEIGHT: 700**   
**font-weight: 800**   
**FONT-WEIGHT: 800**   
**font-weight: 900**   
**FONT-WEIGHT: 900**   
_font-style: italic_   
_FONT-STYLE: ITALIC_   
_**font-weight: bold;font-style: italic**_   
_**FONT-WEIGHT: BOLD;FONT-STYLE: ITALIC**_ 
