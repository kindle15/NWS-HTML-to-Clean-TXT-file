[allas: Country Manager](http://thth)

