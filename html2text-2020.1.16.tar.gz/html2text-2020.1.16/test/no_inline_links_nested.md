[[this][1]that][2]

   [1]: /test2/

   [2]: http://google.com

