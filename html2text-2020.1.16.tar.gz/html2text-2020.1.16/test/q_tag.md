"If this is a test," he said, "then it should pass".

